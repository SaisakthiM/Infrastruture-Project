import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuthStore } from '../store/authStore'
import { roomAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'

function avatarGradient(seed) {
  const gradients = [
    'from-aurora-mint to-aurora-teal',
    'from-aurora-violet to-aurora-pink',
    'from-aurora-amber to-aurora-pink',
    'from-aurora-teal to-aurora-violet',
    'from-aurora-mint to-aurora-violet',
  ]
  let hash = 0
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) % gradients.length
  return gradients[Math.abs(hash)]
}

export default function ChatList({ selectedRoomId, onRoomSelect, onLogout }) {
  const { user, logout } = useAuthStore()
  const [rooms, setRooms] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [newRoomName, setNewRoomName] = useState('')
  const [showAccountMenu, setShowAccountMenu] = useState(false)
  const [activeModal, setActiveModal] = useState(null) // 'profile' | 'settings' | null
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const [soundEnabled, setSoundEnabled] = useState(true)

  useEffect(() => {
    const loadRooms = async () => {
      if (user?.id) {
        try {
          const data = await roomAPI.getUserRooms(user.id)
          setRooms(Array.isArray(data) ? data : [])
        } catch (error) {
          console.error('Failed to load rooms:', error)
          setRooms([])
        } finally {
          setIsLoading(false)
        }
      }
    }

    loadRooms()
    const interval = setInterval(loadRooms, 5000)
    return () => clearInterval(interval)
  }, [user?.id])

  const handleCreateRoom = async (e) => {
    e.preventDefault()
    if (!newRoomName.trim()) return

    try {
      const response = await roomAPI.createRoom(newRoomName, user.id)

      if (response && response.id) {
        await roomAPI.joinRoom(response.id, user.id)
      }

      setNewRoomName('')
      setShowCreateDialog(false)

      const data = await roomAPI.getUserRooms(user.id)
      setRooms(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error('Failed to create room:', error)
    }
  }

  const handleLogout = () => {
    logout()
    onLogout()
  }

  const filteredRooms = rooms.filter(room =>
    room.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="h-full w-full sm:w-80 glass border-r border-aurora-border flex flex-col flex-shrink-0 min-h-0 relative z-10">
      {/* Header */}
      <div className="p-4 border-b border-aurora-border">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setShowAccountMenu(!showAccountMenu)}
            className="flex items-center gap-2 min-w-0 rounded-lg px-1.5 py-1 -ml-1.5 hover:bg-white/5 transition-colors"
          >
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-aurora-mint to-aurora-teal flex items-center justify-center font-bold text-aurora-900 shrink-0">
              {user?.username?.charAt(0).toUpperCase()}
            </div>
            <div className="text-left min-w-0">
              <h1 className="text-lg font-extrabold text-gradient leading-tight">Whisper</h1>
              <p className="text-xs text-white/50 truncate">{user?.username}</p>
            </div>
          </button>

          <div className="relative">
            <motion.button
              onClick={() => setShowAccountMenu(!showAccountMenu)}
              whileTap={{ scale: 0.9 }}
              className="icon-btn text-white/70 hover:text-white"
              title="Account"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
              </svg>
            </motion.button>

            <AnimatePresence>
              {showAccountMenu && (
                <motion.div
                  initial={{ opacity: 0, y: -8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -8, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-44 glass-card text-white z-30 overflow-hidden"
                >
                  <button
                    onClick={() => { setShowAccountMenu(false); setActiveModal('profile') }}
                    className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-colors text-sm flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                    Profile
                  </button>
                  <button
                    onClick={() => { setShowAccountMenu(false); setActiveModal('settings') }}
                    className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-colors text-sm flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    Settings
                  </button>
                  <div className="border-t border-aurora-border" />
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-colors text-sm flex items-center gap-2 text-red-300"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                    Logout
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <svg className="absolute left-3 top-3 w-5 h-5 text-white/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Search chats..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 text-sm"
          />
        </div>
      </div>

      {/* Create Room Button */}
      <div className="p-3 border-b border-aurora-border">
        <AnimatePresence mode="wait" initial={false}>
          {!showCreateDialog ? (
            <motion.button
              key="new-chat"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateDialog(true)}
              whileTap={{ scale: 0.98 }}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              New Chat
            </motion.button>
          ) : (
            <motion.form
              key="create-form"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleCreateRoom}
              className="space-y-2 overflow-hidden"
            >
              <input
                autoFocus
                type="text"
                placeholder="Room name..."
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                className="input-field text-sm"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 text-sm py-2 bg-btn-gradient text-aurora-900 font-semibold rounded-lg hover:opacity-90 transition-opacity"
                >
                  Create
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateDialog(false)}
                  className="flex-1 text-sm py-2 glass text-white rounded-lg hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto min-h-0">
        {isLoading ? (
          <div className="p-4 space-y-2">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-16 rounded-xl shimmer-bg glass" />
            ))}
          </div>
        ) : filteredRooms.length === 0 ? (
          <div className="p-6 text-center text-white/40 text-sm">
            {searchTerm ? 'No chats found' : 'No chats yet. Create one!'}
          </div>
        ) : (
          <AnimatePresence>
            {filteredRooms.map((room, i) => (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, delay: i * 0.03 }}
                onClick={() => onRoomSelect(room.id)}
                className={`m-2 p-3 cursor-pointer rounded-xl flex items-center gap-3 transition-all duration-200 ${
                  selectedRoomId === room.id
                    ? 'bg-white/10 ring-1 ring-aurora-teal/40'
                    : 'hover:bg-white/5'
                }`}
              >
                <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${avatarGradient(room.name)} flex items-center justify-center text-aurora-900 font-bold text-lg shrink-0`}>
                  {room.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-white truncate">{room.name}</h3>
                  <p className="text-xs text-white/40 mt-0.5">
                    {formatDistanceToNow(new Date(room.created_at), { addSuffix: true })}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Profile / Settings Modal */}
      <AnimatePresence>
        {activeModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActiveModal(null)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.96 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card w-full max-w-sm p-6"
            >
              {activeModal === 'profile' ? (
                <>
                  <h3 className="text-lg font-semibold text-white mb-4">Profile</h3>
                  <div className="flex flex-col items-center mb-4">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-aurora-mint to-aurora-teal flex items-center justify-center text-3xl font-bold text-aurora-900 mb-3">
                      {user?.username?.charAt(0).toUpperCase()}
                    </div>
                    <p className="text-white font-semibold text-lg">{user?.username}</p>
                    <p className="text-white/40 text-xs mt-1">User ID: {user?.id}</p>
                  </div>
                </>
              ) : (
                <>
                  <h3 className="text-lg font-semibold text-white mb-4">Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center justify-between py-2 cursor-pointer">
                      <span className="text-sm text-white/80">Notifications</span>
                      <input
                        type="checkbox"
                        checked={notificationsEnabled}
                        onChange={(e) => setNotificationsEnabled(e.target.checked)}
                        className="w-5 h-5 accent-aurora-mint"
                      />
                    </label>
                    <div className="border-t border-aurora-border" />
                    <label className="flex items-center justify-between py-2 cursor-pointer">
                      <span className="text-sm text-white/80">Message sounds</span>
                      <input
                        type="checkbox"
                        checked={soundEnabled}
                        onChange={(e) => setSoundEnabled(e.target.checked)}
                        className="w-5 h-5 accent-aurora-mint"
                      />
                    </label>
                    <div className="border-t border-aurora-border" />
                    <div className="flex items-center justify-between py-2">
                      <span className="text-sm text-white/80">Theme</span>
                      <span className="text-xs text-white/40">Dark (default)</span>
                    </div>
                  </div>
                </>
              )}
              <button
                onClick={() => setActiveModal(null)}
                className="btn-primary w-full mt-6"
              >
                Close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
