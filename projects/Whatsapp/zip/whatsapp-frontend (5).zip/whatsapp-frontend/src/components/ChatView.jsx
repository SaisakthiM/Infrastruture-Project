import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuthStore } from '../store/authStore'
import { useWebSocket } from '../hooks/useWebSocket'
import { roomAPI, mediaAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'

export default function ChatView({ roomId, roomName }) {
  const { user, token } = useAuthStore()
  const { messages, isConnected, error: wsError, sendMessage, sendImage } = useWebSocket(roomId, token)
  const [messageText, setMessageText] = useState('')
  const [members, setMembers] = useState([])
  const [showMembers, setShowMembers] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(null)
  const [previewImage, setPreviewImage] = useState(null)
  const messagesEndRef = useRef(null)
  const fileInputRef = useRef(null)

  useEffect(() => {
    const loadMembers = async () => {
      try {
        const data = await roomAPI.getRoomMembers(roomId)
        setMembers(data || [])
      } catch (error) {
        console.error('Failed to load members:', error)
      }
    }

    if (roomId) {
      loadMembers()
    }
  }, [roomId])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSendMessage = (e) => {
    e.preventDefault()
    if (messageText.trim() && isConnected) {
      sendMessage(messageText)
      setMessageText('')
    }
  }

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith('image/')) {
      alert('Only image files are supported')
      return
    }

    try {
      setUploadProgress(0)
      const result = await mediaAPI.uploadImage(file, setUploadProgress)
      sendImage(result.url, '')
    } catch (err) {
      console.error('Image upload failed:', err)
      alert('Failed to upload image')
    } finally {
      setUploadProgress(null)
      e.target.value = ''
    }
  }

  const isCurrentUserMessage = (senderId) => senderId === user?.id

  const connectionLabel = isConnected
    ? 'Online'
    : (wsError === 'Reconnecting...' ? 'Reconnecting…' : 'Connecting…')

  return (
    <div className="flex-1 flex flex-col h-full relative z-10 min-w-0">
      {/* Header */}
      <div className="glass border-b border-aurora-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-aurora-violet to-aurora-teal flex items-center justify-center font-bold text-aurora-900 shrink-0">
              {roomName?.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <h2 className="text-lg font-semibold text-white truncate">{roomName}</h2>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`relative inline-flex w-2 h-2 rounded-full ${isConnected ? 'bg-aurora-mint' : 'bg-aurora-amber'}`}>
                  {isConnected && (
                    <span className="absolute inset-0 rounded-full bg-aurora-mint animate-pulse-glow" />
                  )}
                </span>
                <p className="text-xs text-white/50">{connectionLabel}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowMembers(!showMembers)}
              className="icon-btn text-white/70 hover:text-white"
              title="Members"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 12H9m6 0a6 6 0 11-12 0 6 6 0 0112 0z" />
              </svg>
            </motion.button>

            <div className="relative">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowMenu(!showMenu)}
                className="icon-btn text-white/70 hover:text-white"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
                </svg>
              </motion.button>
              <AnimatePresence>
                {showMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -8, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-48 glass-card text-white z-20 overflow-hidden"
                  >
                    <button className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-colors text-sm">Search Messages</button>
                    <button className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-colors text-sm">Media</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Messages Area */}
        <div className="flex-1 flex flex-col chat-bg min-w-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 flex flex-col">
            {messages.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-full text-white/40"
              >
                <svg className="w-16 h-16 mb-3 opacity-40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-sm">No messages yet</p>
                <p className="text-xs text-white/30">Start the conversation!</p>
              </motion.div>
            ) : (
              messages.map((msg, idx) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 12, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
                  className={`flex ${isCurrentUserMessage(msg.sender_id) ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`message-bubble ${
                      isCurrentUserMessage(msg.sender_id) ? 'message-sent' : 'message-received'
                    } ${msg.message_type === 'image' ? 'p-1.5' : ''}`}
                  >
                    {msg.message_type === 'image' && msg.media_url ? (
                      <div className="space-y-1">
                        <img
                          src={mediaAPI.resolveUrl(msg.media_url)}
                          alt="shared media"
                          className="rounded-xl max-h-72 object-cover cursor-pointer hover:opacity-90 transition-opacity"
                          onClick={() => setPreviewImage(mediaAPI.resolveUrl(msg.media_url))}
                          loading="lazy"
                        />
                        {msg.content && (
                          <p className="break-words px-1.5">{msg.content}</p>
                        )}
                        <p className={`text-xs px-1.5 pb-0.5 ${isCurrentUserMessage(msg.sender_id) ? 'text-aurora-900/60' : 'text-white/40'}`}>
                          {formatDistanceToNow(new Date(msg.created_at), { addSuffix: false })}
                        </p>
                      </div>
                    ) : (
                      <>
                        <p className="break-words">{msg.content}</p>
                        <p className={`text-xs mt-1 ${isCurrentUserMessage(msg.sender_id) ? 'text-aurora-900/60' : 'text-white/40'}`}>
                          {formatDistanceToNow(new Date(msg.created_at), { addSuffix: false })}
                        </p>
                      </>
                    )}
                  </div>
                </motion.div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Upload progress bar */}
          <AnimatePresence>
            {uploadProgress !== null && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="px-4 pb-2"
              >
                <div className="glass rounded-full h-2 overflow-hidden">
                  <motion.div
                    className="h-full bg-btn-gradient"
                    animate={{ width: `${uploadProgress}%` }}
                    transition={{ ease: 'easeOut' }}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Message Input */}
          <form onSubmit={handleSendMessage} className="p-4 flex gap-3 items-center">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <motion.button
              type="button"
              whileTap={{ scale: 0.9 }}
              onClick={() => fileInputRef.current?.click()}
              disabled={!isConnected}
              className="icon-btn text-white/70 hover:text-aurora-teal disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
              title="Send image"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 16l5-5a2 2 0 012.828 0l5.172 5.172M14 14l1-1a2 2 0 012.828 0L21 16M5 4h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V5a1 1 0 011-1z" />
                <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor" stroke="none" />
              </svg>
            </motion.button>

            <input
              type="text"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Type a message..."
              disabled={!isConnected}
              className="input-field flex-1 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
            />
            <motion.button
              type="submit"
              whileTap={{ scale: 0.92 }}
              whileHover={{ scale: 1.05 }}
              disabled={!isConnected || !messageText.trim()}
              className="bg-btn-gradient disabled:opacity-40 disabled:cursor-not-allowed text-aurora-900 p-3 rounded-full transition-shadow shadow-lg hover:shadow-[0_0_20px_rgba(52,232,158,0.5)] shrink-0"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M16.6915026,12.4744748 L3.50612381,13.2599618 C3.19218622,13.2599618 3.03521743,13.4170592 3.03521743,13.5741566 L1.15159189,20.0151496 C0.8376543,20.8006365 0.99,21.89 1.77946707,22.52 C2.40,22.99 3.50612381,23.1 4.13399899,22.99 L21.714504,14.0454487 C22.6563168,13.5741566 23.1272231,12.6315722 22.9702544,11.6889879 L4.13399899,1.01345964 C3.34915502,0.9 2.40734225,1.00636533 1.77946707,1.4776575 C0.994623095,2.10604706 0.837654326,3.0486314 1.15159189,3.98701575 L3.03521743,10.4280088 C3.03521743,10.5851061 3.19218622,10.7422035 3.50612381,10.7422035 L16.6915026,11.5276905 C16.6915026,11.5276905 17.1624089,11.5276905 17.1624089,12.0989827 C17.1624089,12.6315722 16.6915026,12.4744748 16.6915026,12.4744748 Z" />
              </svg>
            </motion.button>
          </form>
        </div>

        {/* Members Sidebar */}
        <AnimatePresence>
          {showMembers && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 288, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              className="border-l border-aurora-border glass flex flex-col overflow-hidden shrink-0"
            >
              <div className="p-4 border-b border-aurora-border w-72">
                <h3 className="font-semibold text-white mb-1">Members</h3>
                <p className="text-xs text-white/40">{members.length} members</p>
              </div>
              <div className="flex-1 overflow-y-auto w-72">
                {members.map(member => (
                  <div
                    key={member.user_id}
                    className="p-4 border-b border-aurora-border hover:bg-white/5 transition-colors"
                  >
                    <p className="font-medium text-white text-sm">{member.username}</p>
                    <p className="text-xs text-white/40 mt-1">
                      Last seen {formatDistanceToNow(new Date(member.last_seen_at), { addSuffix: true })}
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Image preview lightbox */}
      <AnimatePresence>
        {previewImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setPreviewImage(null)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 cursor-zoom-out"
          >
            <motion.img
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              src={previewImage}
              alt="preview"
              className="max-h-[85vh] max-w-[90vw] rounded-2xl shadow-2xl"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
