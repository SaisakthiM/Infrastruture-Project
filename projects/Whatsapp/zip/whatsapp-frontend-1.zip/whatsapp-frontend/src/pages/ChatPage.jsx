import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAuthStore } from '../store/authStore'
import { roomAPI } from '../services/api'
import ChatList from '../components/ChatList'

export default function ChatPage() {
  const navigate = useNavigate()
  const { user, token } = useAuthStore()
  const [selectedRoomId, setSelectedRoomId] = useState(null)
  const [selectedRoomName, setSelectedRoomName] = useState('')
  const [rooms, setRooms] = useState([])

  useEffect(() => {
    if (!user || !token) {
      navigate('/login')
    }
  }, [user, token, navigate])

  useEffect(() => {
    const loadRooms = async () => {
      if (user?.id) {
        try {
          const data = await roomAPI.getUserRooms(user.id)
          setRooms(data || [])
          if (data && data.length > 0 && !selectedRoomId) {
            setSelectedRoomId(data[0].id)
            setSelectedRoomName(data[0].name)
          }
        } catch (error) {
          console.error('Failed to load rooms:', error)
        }
      }
    }

    loadRooms()
  }, [user?.id])

  const handleRoomSelect = (roomId) => {
    setSelectedRoomId(roomId)
    const room = rooms.find(r => r.id === roomId)
    if (room) {
      setSelectedRoomName(room.name)
    }
  }

  const handleLogout = () => {
    navigate('/login')
  }

  return (
    <div className="aurora-bg fixed inset-0 flex">
      {/* Sidebar */}
      <ChatList
        selectedRoomId={selectedRoomId}
        onRoomSelect={handleRoomSelect}
        onLogout={handleLogout}
      />

      {/* Main Chat Area */}
      <div className="flex flex-col flex-1 relative z-10">
        {/* Persistent Header */}
        <header className="w-full bg-aurora-glass border-b border-aurora-border backdrop-blur-xl z-20">
          <div className="flex items-center justify-between px-4 py-3">
            <h1 className="font-semibold text-white">
              {selectedRoomName || 'Welcome'}
            </h1>
            <button
              onClick={handleLogout}
              className="btn-secondary"
            >
              Logout
            </button>
          </div>
        </header>

        {/* Chat Body */}
        <div className="flex flex-col flex-1">
          {selectedRoomId ? (
            <div className="flex flex-col h-full">
              {/* Scrollable messages */}
              <div className="flex-1 overflow-y-auto p-4 chat-bg">
                {/* Replace with your messages rendering */}
                <p className="text-white/60">Messages for {selectedRoomName} will appear here.</p>
              </div>

              {/* Input bar pinned at bottom */}
              <div className="border-t border-aurora-border bg-aurora-glass p-3">
                <form className="flex items-center gap-2">
                  <button type="button" className="icon-btn">📎</button>
                  <input
                    type="text"
                    placeholder="Type a message..."
                    className="flex-1 input-field"
                  />
                  <button type="submit" className="btn-primary">Send</button>
                </form>
              </div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="hidden sm:flex flex-1 items-center justify-center"
            >
              <div className="text-center">
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-btn-gradient mb-4 shadow-[0_0_50px_rgba(52,232,158,0.35)]"
                >
                  <svg className="w-10 h-10 text-aurora-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </motion.div>
                <p className="text-lg font-semibold text-white">Select a chat to start messaging</p>
                <p className="text-sm text-white/40 mt-2">Or create a new one from the sidebar</p>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}
