# WhatsApp Clone - React + MUI Frontend

A modern WhatsApp-like chat application built with **React**, **Material-UI (MUI)**, and **React Router**, connected to your Rust backend.

## ✨ Features

- **Modern UI** - WhatsApp-like design with MUI components
- **Real-time Messaging** - WebSocket support for instant messages
- **Chat Rooms** - Create groups or join existing rooms
- **User Management** - Update profile, change username, delete account
- **Member List** - View all members in a room
- **Responsive Design** - Works on desktop and mobile
- **WhatsApp Chat Background** - Authentic chat background pattern
- **Message History** - Loads and displays past messages
- **Online Status** - Real-time WebSocket connection indicator

## 📋 Prerequisites

- Node.js 14+ and npm
- Your Rust backend running (default: `http://localhost:3000`)

## 🚀 Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure API URL

Create a `.env` file in the root directory:

```bash
cp .env.example .env
```

Edit `.env` and set your backend URL:

```
REACT_APP_API_URL=http://localhost:3000
```

If using a different host or port, update accordingly.

### 3. Start Development Server

```bash
npm start
```

The app will open at `http://localhost:3000` (Vite/Create React App).

## 🏗️ Project Structure

```
src/
├── api/              # Backend API calls
├── components/       # Reusable UI components
│   ├── Sidebar.js          - Room list sidebar
│   ├── ChatWindow.js        - Main chat view
│   ├── ProfileMenu.js       - User account options
│   ├── NewRoomDialog.js     - Create/join room modal
│   └── MembersDrawer.js     - Room members drawer
├── context/          # Auth context & state
├── hooks/            # Custom hooks
│   └── useWebSocket.js      - WebSocket connection hook
├── pages/            # Page components
│   ├── AuthPage.js          - Login/Register
│   └── HomePage.js          - Main chat interface
├── App.js            # Main app with routing
└── index.js          # React entry point
```

## 🎨 Design Highlights

- **WhatsApp Green** - Authentic #075E54 branding
- **Chat Background** - SVG-based tiled pattern (#e5ddd5)
- **Message Bubbles** - Right-aligned (yours) and left-aligned (others)
- **Profile Avatar** - Color-coded by user/room name
- **Real-time Indicators** - Online/connecting status

## 📡 API Integration

The app calls these backend endpoints:

### Authentication
- `POST /login` - Sign in
- `POST /users` - Register

### Users
- `GET /users/:id` - Get user info
- `PUT /users/:id` - Update username
- `DELETE /users/:id` - Delete account

### Rooms
- `POST /room` - Create room
- `POST /room/join` - Join room
- `GET /rooms?user_id=...` - Get user's rooms
- `GET /room/:id/members` - Get room members

### Messages
- `GET /message?room_id=...&user_id=...` - Get messages
- `POST /message` - Send message
- `WS /ws/:id?token=...` - WebSocket connection

All endpoints require authentication with a Bearer token (except login/register).

## 🔌 WebSocket Usage

The app automatically connects to WebSocket when a room is selected:

```javascript
WS /ws/{roomId}?token={authToken}
```

Messages are sent as plain text and received as JSON with `id`, `sender_id`, `content`, `created_at`.

## 🔐 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `REACT_APP_API_URL` | `http://localhost:3000` | Backend API base URL |

## 🛠️ Development Tips

- **Responsive Design**: The sidebar hides on mobile; tap room to open chat
- **Token Storage**: Auth token is saved in localStorage (key: `wa_auth`)
- **Auto-reconnect**: WebSocket auto-connects when room changes
- **Scroll to Bottom**: Messages auto-scroll to latest
- **Duplicate Prevention**: Messages deduplicated by ID

## 📦 Build for Production

```bash
npm run build
```

Creates optimized production build in `build/` directory.

## 🎯 Next Steps

1. Ensure your Rust backend is running
2. Update `REACT_APP_API_URL` in `.env` if needed
3. Run `npm start`
4. Sign up or log in with test credentials
5. Create a room or join one with a room UUID

## 📝 License

MIT

---

Built with ❤️ using React, MUI, and WebSocket magic.
