const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000';

function authHeaders(token) {
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function handleResponse(res) {
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(text || `HTTP ${res.status}`);
  }
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) return res.json();
  return null;
}

// ── Auth ────────────────────────────────────────────────────────────────────
export async function register(username, password) {
  const res = await fetch(`${BASE_URL}/users`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify({ username, password }),
  });
  return handleResponse(res);
}

export async function login(username, password) {
  const res = await fetch(`${BASE_URL}/login`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify({ username, password }),
  });
  return handleResponse(res);
}

// ── Users ────────────────────────────────────────────────────────────────────
export async function getUser(userId, token) {
  const res = await fetch(`${BASE_URL}/users/${userId}`, {
    headers: authHeaders(token),
  });
  return handleResponse(res);
}

export async function updateUser(userId, newName, token) {
  const res = await fetch(`${BASE_URL}/users/${userId}`, {
    method: 'PUT',
    headers: authHeaders(token),
    body: JSON.stringify({ new_name: newName }),
  });
  return handleResponse(res);
}

export async function deleteUser(userId, token) {
  const res = await fetch(`${BASE_URL}/users/${userId}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
  return handleResponse(res);
}

// ── Rooms ────────────────────────────────────────────────────────────────────
export async function createRoom(name, token) {
  const res = await fetch(`${BASE_URL}/room`, {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify({ name }),
  });
  return handleResponse(res);
}

export async function joinRoom(roomId, userId, token) {
  const res = await fetch(`${BASE_URL}/room/join`, {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify({ room_id: roomId, user_id: userId }),
  });
  return handleResponse(res);
}

export async function getUserRooms(userId, token) {
  const res = await fetch(`${BASE_URL}/rooms?user_id=${userId}`, {
    headers: authHeaders(token),
  });
  return handleResponse(res);
}

export async function getRoomMembers(roomId, token) {
  const res = await fetch(`${BASE_URL}/room/${roomId}/members`, {
    headers: authHeaders(token),
  });
  return handleResponse(res);
}

// ── Messages ─────────────────────────────────────────────────────────────────
export async function getMessages(roomId, userId, token) {
  const res = await fetch(`${BASE_URL}/message?room_id=${roomId}&user_id=${userId}`, {
    headers: authHeaders(token),
  });
  return handleResponse(res);
}

export async function sendMessage(roomId, senderId, content, token) {
  const res = await fetch(`${BASE_URL}/message`, {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify({ room_id: roomId, sender_id: senderId, content }),
  });
  return handleResponse(res);
}

// ── WebSocket ────────────────────────────────────────────────────────────────
export function createWebSocket(roomId, token) {
  const wsBase = BASE_URL.replace(/^http/, 'ws');
  return new WebSocket(`${wsBase}/ws/${roomId}?token=${token}`);
}
