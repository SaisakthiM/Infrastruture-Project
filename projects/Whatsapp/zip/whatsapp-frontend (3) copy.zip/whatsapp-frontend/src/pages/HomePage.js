import React, { useState } from 'react';
import { Box, Typography } from '@mui/material';
import Sidebar from '../components/Sidebar';
import ChatWindow from '../components/ChatWindow';
import ChatIcon from '@mui/icons-material/Chat';

export default function HomePage() {
  const [selectedRoom, setSelectedRoom] = useState(null);

  return (
    <Box sx={{ display: 'flex', height: '100vh', width: '100%', overflow: 'hidden' }}>
      {/* Sidebar */}
      <Box sx={{ display: { xs: selectedRoom ? 'none' : 'flex', md: 'flex' }, flexShrink: 0 }}>
        <Sidebar selectedRoom={selectedRoom} onSelectRoom={setSelectedRoom} />
      </Box>

      {/* Chat window or empty state */}
      {selectedRoom ? (
        <ChatWindow
          room={selectedRoom}
          onBack={() => setSelectedRoom(null)}
        />
      ) : (
        <Box
          sx={{
            flex: 1,
            display: { xs: 'none', md: 'flex' },
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            bgcolor: '#fff',
            gap: 2,
          }}
        >
          <ChatIcon sx={{ fontSize: 80, color: '#ccc' }} />
          <Typography variant="h6" color="text.secondary">
            Select a chat to start messaging
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Or create a new group
          </Typography>
        </Box>
      )}
    </Box>
  );
}
