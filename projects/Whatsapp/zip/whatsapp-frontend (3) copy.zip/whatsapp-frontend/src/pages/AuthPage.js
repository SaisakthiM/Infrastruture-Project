import React, { useState } from 'react';
import {
  Box, TextField, Button, Typography, Tab, Tabs, Alert, CircularProgress, Paper,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import * as api from '../api';

export default function AuthPage() {
  const [tab, setTab] = useState(0);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const isLogin = tab === 0;

  async function handleSubmit(e) {
    e.preventDefault();
    if (!username.trim() || !password.trim()) return;
    setLoading(true);
    setError('');
    try {
      let data;
      if (isLogin) {
        data = await api.login(username.trim(), password);
      } else {
        data = await api.register(username.trim(), password);
      }
      login(data.id, data.token, username.trim());
      navigate('/');
    } catch (err) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #075E54 0%, #128C7E 50%, #25D366 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        p: 2,
      }}
    >
      <Paper
        elevation={24}
        sx={{ width: '100%', maxWidth: 400, borderRadius: 3, overflow: 'hidden' }}
      >
        {/* Header */}
        <Box sx={{ bgcolor: '#075E54', p: 4, textAlign: 'center' }}>
          <Box
            component="img"
            src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
            alt="WhatsApp"
            sx={{ width: 64, height: 64, mb: 1 }}
          />
          <Typography variant="h5" sx={{ color: '#fff', fontWeight: 700 }}>
            WhatsApp
          </Typography>
          <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
            Simple. Reliable. Private.
          </Typography>
        </Box>

        {/* Tabs */}
        <Tabs
          value={tab}
          onChange={(_, v) => { setTab(v); setError(''); }}
          variant="fullWidth"
          TabIndicatorProps={{ style: { backgroundColor: '#25D366' } }}
          sx={{ bgcolor: '#f0f0f0' }}
        >
          <Tab label="Sign In" sx={{ '&.Mui-selected': { color: '#075E54' } }} />
          <Tab label="Register" sx={{ '&.Mui-selected': { color: '#075E54' } }} />
        </Tabs>

        {/* Form */}
        <Box component="form" onSubmit={handleSubmit} sx={{ p: 4, pt: 3 }}>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <TextField
            label="Username"
            fullWidth
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            sx={{ mb: 2 }}
            autoFocus
            autoComplete="username"
          />
          <TextField
            label="Password"
            type="password"
            fullWidth
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            sx={{ mb: 3 }}
            autoComplete={isLogin ? 'current-password' : 'new-password'}
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            size="large"
            disabled={loading}
            sx={{
              bgcolor: '#25D366',
              '&:hover': { bgcolor: '#1ebe5a' },
              borderRadius: 2,
              py: 1.5,
              fontWeight: 700,
              fontSize: '1rem',
            }}
          >
            {loading ? <CircularProgress size={22} color="inherit" /> : (isLogin ? 'Sign In' : 'Create Account')}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
