import React, { useState, useEffect } from 'react';
import {
  Drawer, Box, Typography, List, ListItem, ListItemAvatar,
  ListItemText, Avatar, CircularProgress, Divider,
} from '@mui/material';
import GroupIcon from '@mui/icons-material/Group';
import { useAuth } from '../context/AuthContext';
import * as api from '../api';

function memberColor(id) {
  const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F'];
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h + id.charCodeAt(i)) % colors.length;
  return colors[h];
}

export default function MembersDrawer({ open, onClose, room }) {
  const { auth } = useAuth();
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !room) return;
    setLoading(true);
    api.getRoomMembers(room.id, auth.token)
      .then((data) => setMembers(Array.isArray(data) ? data : []))
      .catch(() => setMembers([]))
      .finally(() => setLoading(false));
  }, [open, room, auth]);

  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: 360, display: 'flex', flexDirection: 'column', height: '100vh' }}>
        {/* Header */}
        <Box sx={{ bgcolor: '#075E54', px: 2, py: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <GroupIcon sx={{ color: '#fff', fontSize: 28 }} />
            <Box>
              <Typography sx={{ color: '#fff', fontWeight: 700, fontSize: 16 }}>
                {room?.name}
              </Typography>
              <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.7)' }}>
                {members.length} members
              </Typography>
            </Box>
          </Box>
        </Box>
        <Divider />

        {/* Members list */}
        <Box sx={{ flex: 1, overflowY: 'auto' }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', pt: 4 }}>
              <CircularProgress size={28} />
            </Box>
          ) : members.length === 0 ? (
            <Box sx={{ textAlign: 'center', pt: 6, px: 3 }}>
              <Typography variant="body2" color="text.secondary">
                No members yet
              </Typography>
            </Box>
          ) : (
            <List disablePadding>
              {members.map((member, idx) => (
                <React.Fragment key={member.id}>
                  <ListItem sx={{ px: 2, py: 1 }}>
                    <ListItemAvatar>
                      <Avatar
                        sx={{
                          bgcolor: memberColor(member.id),
                          fontWeight: 700,
                          width: 44,
                          height: 44,
                        }}
                      >
                        {(member.name || 'U').charAt(0).toUpperCase()}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={
                        <Typography sx={{ fontWeight: 600, fontSize: 15 }}>
                          {member.name}
                          {member.id === auth.id && (
                            <Typography component="span" sx={{ fontSize: 12, color: '#888', ml: 1 }}>
                              (you)
                            </Typography>
                          )}
                        </Typography>
                      }
                      secondary={
                        <Typography variant="caption" color="text.secondary">
                          {member.id.slice(0, 12)}...
                        </Typography>
                      }
                    />
                  </ListItem>
                  {idx < members.length - 1 && <Divider component="li" />}
                </React.Fragment>
              ))}
            </List>
          )}
        </Box>
      </Box>
    </Drawer>
  );
}
