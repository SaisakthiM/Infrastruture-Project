import React, { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, TextField, Tabs, Tab, Alert, CircularProgress,
} from '@mui/material';
import { useAuth } from '../context/AuthContext';
import * as api from '../api';

export default function NewRoomDialog({ open, onClose, onCreated }) {
  const { auth } = useAuth();
  const [tab, setTab] = useState(0);
  const [roomName, setRoomName] = useState('');
  const [roomId, setRoomId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const reset = () => {
    setRoomName('');
    setRoomId('');
    setError('');
    setLoading(false);
  };

  const handleClose = () => { reset(); onClose(); };

  const handleCreate = async () => {
    if (!roomName.trim()) return;
    setLoading(true);
    setError('');
    try {
      const room = await api.createRoom(roomName.trim(), auth.token);
      // Auto-join the created room
      await api.joinRoom(room.id, auth.id, auth.token);
      onCreated();
      handleClose();
    } catch (e) {
      setError(e.message || 'Failed to create room');
    } finally {
      setLoading(false);
    }
  };

  const handleJoin = async () => {
    if (!roomId.trim()) return;
    setLoading(true);
    setError('');
    try {
      await api.joinRoom(roomId.trim(), auth.id, auth.token);
      onCreated();
      handleClose();
    } catch (e) {
      setError(e.message || 'Failed to join room');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="xs" fullWidth>
      <DialogTitle>New Chat</DialogTitle>
      <Tabs
        value={tab}
        onChange={(_, v) => { setTab(v); setError(''); }}
        variant="fullWidth"
        TabIndicatorProps={{ style: { backgroundColor: '#25D366' } }}
        sx={{ borderBottom: '1px solid #eee' }}
      >
        <Tab label="Create Group" sx={{ '&.Mui-selected': { color: '#075E54' } }} />
        <Tab label="Join by ID" sx={{ '&.Mui-selected': { color: '#075E54' } }} />
      </Tabs>
      <DialogContent sx={{ pt: 2 }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {tab === 0 ? (
          <TextField
            autoFocus
            fullWidth
            label="Group name"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
            placeholder="e.g. Family, Work team…"
          />
        ) : (
          <TextField
            autoFocus
            fullWidth
            label="Room ID (UUID)"
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
            placeholder="Paste the room UUID"
          />
        )}
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          disabled={loading || (tab === 0 ? !roomName.trim() : !roomId.trim())}
          onClick={tab === 0 ? handleCreate : handleJoin}
          sx={{ bgcolor: '#075E54', '&:hover': { bgcolor: '#064d44' } }}
        >
          {loading ? <CircularProgress size={20} color="inherit" /> : (tab === 0 ? 'Create' : 'Join')}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
