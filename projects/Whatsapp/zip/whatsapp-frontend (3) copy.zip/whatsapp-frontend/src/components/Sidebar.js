import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, List, ListItemButton, ListItemAvatar, ListItemText, Avatar,
  Typography, IconButton, Divider, TextField, InputAdornment, CircularProgress,
  Fab, Tooltip,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import GroupsIcon from '@mui/icons-material/Groups';
import { useAuth } from '../context/AuthContext';
import * as api from '../api';
import NewRoomDialog from './NewRoomDialog';
import ProfileMenu from './ProfileMenu';

function roomInitial(name) {
  return (name || '?').charAt(0).toUpperCase();
}

function roomColor(name) {
  const colors = ['#075E54', '#128C7E', '#25D366', '#34B7F1', '#ECE5DD'];
  let h = 0;
  for (let i = 0; i < (name || '').length; i++) h = (h + name.charCodeAt(i)) % colors.length;
  return colors[h];
}

export default function Sidebar({ selectedRoom, onSelectRoom }) {
  const { auth } = useAuth();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [newRoomOpen, setNewRoomOpen] = useState(false);

  const loadRooms = useCallback(async () => {
    if (!auth) return;
    try {
      const data = await api.getUserRooms(auth.id, auth.token);
      setRooms(data || []);
    } catch {
      setRooms([]);
    } finally {
      setLoading(false);
    }
  }, [auth]);

  useEffect(() => {
    loadRooms();
    const interval = setInterval(loadRooms, 10000);
    return () => clearInterval(interval);
  }, [loadRooms]);

  const filtered = rooms.filter((r) =>
    r.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Box
      sx={{
        width: { xs: '100%', md: 360 },
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        bgcolor: '#fff',
        borderRight: '1px solid #e0e0e0',
        flexShrink: 0,
      }}
    >
      {/* Top bar */}
      <Box
        sx={{
          bgcolor: '#075E54',
          px: 2,
          py: 1.5,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Avatar sx={{ bgcolor: '#25D366', width: 40, height: 40, fontWeight: 700 }}>
            {(auth?.username || 'U').charAt(0).toUpperCase()}
          </Avatar>
          <Typography sx={{ color: '#fff', fontWeight: 600, fontSize: 16 }}>
            {auth?.username}
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          <Tooltip title="New group / join room">
            <IconButton sx={{ color: '#fff' }} onClick={() => setNewRoomOpen(true)}>
              <AddIcon />
            </IconButton>
          </Tooltip>
          <ProfileMenu onRoomsChange={loadRooms} />
        </Box>
      </Box>

      {/* Search */}
      <Box sx={{ p: 1.5, bgcolor: '#f0f0f0' }}>
        <TextField
          fullWidth
          size="small"
          placeholder="Search or start new chat"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ color: '#888', fontSize: 20 }} />
              </InputAdornment>
            ),
            sx: { bgcolor: '#fff', borderRadius: 4, fontSize: 14 },
          }}
        />
      </Box>

      <Divider />

      {/* Room list */}
      <Box sx={{ flex: 1, overflowY: 'auto' }}>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', pt: 4 }}>
            <CircularProgress size={28} sx={{ color: '#25D366' }} />
          </Box>
        ) : filtered.length === 0 ? (
          <Box sx={{ textAlign: 'center', pt: 6, px: 3 }}>
            <GroupsIcon sx={{ fontSize: 48, color: '#ccc', mb: 1 }} />
            <Typography variant="body2" color="text.secondary">
              {search ? 'No chats found' : 'No chats yet. Create or join one!'}
            </Typography>
          </Box>
        ) : (
          <List disablePadding>
            {filtered.map((room, idx) => (
              <React.Fragment key={room.id}>
                <ListItemButton
                  selected={selectedRoom?.id === room.id}
                  onClick={() => onSelectRoom(room)}
                  sx={{
                    px: 2,
                    py: 1.2,
                    '&.Mui-selected': { bgcolor: '#f0f0f0' },
                    '&:hover': { bgcolor: '#f5f5f5' },
                  }}
                >
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: roomColor(room.name), fontWeight: 700, width: 46, height: 46 }}>
                      {roomInitial(room.name)}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Typography sx={{ fontWeight: 600, fontSize: 15 }} noWrap>
                        {room.name}
                      </Typography>
                    }
                    secondary={
                      <Typography variant="caption" color="text.secondary" noWrap>
                        {new Date(room.created_at).toLocaleDateString()}
                      </Typography>
                    }
                  />
                </ListItemButton>
                {idx < filtered.length - 1 && (
                  <Divider variant="inset" component="li" />
                )}
              </React.Fragment>
            ))}
          </List>
        )}
      </Box>

      <NewRoomDialog
        open={newRoomOpen}
        onClose={() => setNewRoomOpen(false)}
        onCreated={loadRooms}
      />
    </Box>
  );
}
