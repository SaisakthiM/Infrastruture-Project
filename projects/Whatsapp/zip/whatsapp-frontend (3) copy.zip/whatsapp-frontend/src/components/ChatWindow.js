import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Box, Typography, TextField, IconButton, Avatar, Tooltip,
  CircularProgress, Chip, Paper, Divider,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import GroupIcon from '@mui/icons-material/Group';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { useAuth } from '../context/AuthContext';
import { useWebSocket } from '../hooks/useWebSocket';
import MembersDrawer from './MembersDrawer';
import * as api from '../api';

// WhatsApp classic tiled chat background (SVG data URL)
const WA_BG = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Cdefs%3E%3Cpattern id='bg' x='0' y='0' width='100' height='100' patternUnits='userSpaceOnUse'%3E%3Crect width='100' height='100' fill='%23e5ddd5'/%3E%3Ccircle cx='15' cy='15' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='45' cy='15' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='75' cy='15' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='30' cy='30' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='60' cy='30' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='90' cy='30' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='15' cy='45' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='45' cy='45' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='75' cy='45' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='30' cy='60' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='60' cy='60' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='90' cy='60' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='15' cy='75' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='45' cy='75' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='75' cy='75' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='30' cy='90' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='60' cy='90' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Ccircle cx='90' cy='90' r='1.5' fill='%23d4c9bd' opacity='0.6'/%3E%3Cpath d='M20 20 Q25 15 30 20 Q35 15 40 20' stroke='%23d4c9bd' stroke-width='0.8' fill='none' opacity='0.4'/%3E%3Cpath d='M55 55 Q60 50 65 55 Q70 50 75 55' stroke='%23d4c9bd' stroke-width='0.8' fill='none' opacity='0.4'/%3E%3Cpath d='M5 65 Q10 60 15 65 Q20 60 25 65' stroke='%23d4c9bd' stroke-width='0.8' fill='none' opacity='0.4'/%3E%3Cpath d='M70 10 Q75 5 80 10 Q85 5 90 10' stroke='%23d4c9bd' stroke-width='0.8' fill='none' opacity='0.4'/%3E%3C/pattern%3E%3C/defs%3E%3Crect width='100' height='100' fill='url(%23bg)'/%3E%3C/svg%3E")`;

function formatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function groupByDate(messages) {
  const groups = [];
  let currentDate = null;
  messages.forEach((msg) => {
    const d = new Date(msg.created_at);
    const label = d.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    if (label !== currentDate) {
      groups.push({ type: 'date', label });
      currentDate = label;
    }
    groups.push({ type: 'msg', ...msg });
  });
  return groups;
}

export default function ChatWindow({ room, onBack }) {
  const { auth } = useAuth();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [membersOpen, setMembersOpen] = useState(false);
  const bottomRef = useRef(null);

  // Load historical messages
  useEffect(() => {
    if (!room) return;
    setLoading(true);
    setMessages([]);
    api.getMessages(room.id, auth.id, auth.token)
      .then((data) => setMessages(Array.isArray(data) ? data : []))
      .catch(() => setMessages([]))
      .finally(() => setLoading(false));
  }, [room, auth]);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const onMessage = useCallback((data) => {
    setMessages((prev) => {
      // Deduplicate by id
      if (prev.some((m) => m.id === data.id)) return prev;
      return [...prev, data];
    });
  }, []);

  const { connected, send } = useWebSocket(room?.id, auth.token, onMessage);

  const handleSend = () => {
    const text = input.trim();
    if (!text || !connected) return;
    send(text);
    setInput('');
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const items = groupByDate(messages);

  return (
    <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
      {/* Chat header */}
      <Box
        sx={{
          bgcolor: '#075E54',
          px: 1.5,
          py: 1,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
          zIndex: 10,
        }}
      >
        <IconButton sx={{ color: '#fff', display: { md: 'none' } }} onClick={onBack}>
          <ArrowBackIcon />
        </IconButton>
        <Avatar sx={{ bgcolor: '#128C7E', width: 42, height: 42, fontWeight: 700 }}>
          {(room?.name || '?').charAt(0).toUpperCase()}
        </Avatar>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography sx={{ color: '#fff', fontWeight: 600, fontSize: 16 }} noWrap>
            {room?.name}
          </Typography>
          <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.7)' }}>
            {connected ? '● Online' : '○ Connecting…'}
          </Typography>
        </Box>
        <Tooltip title="Members">
          <IconButton sx={{ color: '#fff' }} onClick={() => setMembersOpen(true)}>
            <GroupIcon />
          </IconButton>
        </Tooltip>
        <Tooltip title="Room ID (share to invite)">
          <Chip
            label="ID"
            size="small"
            onClick={() => { navigator.clipboard.writeText(room.id); }}
            sx={{ bgcolor: 'rgba(255,255,255,0.15)', color: '#fff', cursor: 'pointer', fontWeight: 600 }}
          />
        </Tooltip>
      </Box>

      {/* Messages area */}
      <Box
        sx={{
          flex: 1,
          overflowY: 'auto',
          background: WA_BG,
          backgroundSize: '100px 100px',
          px: { xs: 1, md: 2 },
          py: 2,
          display: 'flex',
          flexDirection: 'column',
          gap: 0.5,
        }}
      >
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', pt: 4 }}>
            <CircularProgress size={28} sx={{ color: '#25D366' }} />
          </Box>
        )}

        {items.map((item, idx) => {
          if (item.type === 'date') {
            return (
              <Box key={idx} sx={{ display: 'flex', justifyContent: 'center', my: 1 }}>
                <Chip
                  label={item.label}
                  size="small"
                  sx={{ bgcolor: 'rgba(255,255,255,0.85)', fontSize: 11, fontWeight: 500 }}
                />
              </Box>
            );
          }

          const isMine = item.sender_id === auth.id;
          return (
            <Box
              key={item.id || idx}
              sx={{
                display: 'flex',
                justifyContent: isMine ? 'flex-end' : 'flex-start',
                px: 0.5,
              }}
            >
              <Paper
                elevation={1}
                sx={{
                  maxWidth: { xs: '82%', md: '60%' },
                  px: 1.5,
                  pt: 0.8,
                  pb: 0.5,
                  borderRadius: isMine
                    ? '12px 2px 12px 12px'
                    : '2px 12px 12px 12px',
                  bgcolor: isMine ? '#dcf8c6' : '#fff',
                  position: 'relative',
                }}
              >
                {!isMine && (
                  <Typography sx={{ fontSize: 12, fontWeight: 700, color: '#075E54', mb: 0.2 }}>
                    {item.sender_id?.slice(0, 8)}
                  </Typography>
                )}
                <Typography
                  sx={{
                    fontSize: 14.5,
                    lineHeight: 1.45,
                    wordBreak: 'break-word',
                    whiteSpace: 'pre-wrap',
                  }}
                >
                  {item.content}
                </Typography>
                <Typography
                  sx={{
                    fontSize: 10.5,
                    color: '#999',
                    textAlign: 'right',
                    mt: 0.3,
                    lineHeight: 1,
                  }}
                >
                  {formatTime(item.created_at)}
                  {isMine && ' ✓✓'}
                </Typography>
              </Paper>
            </Box>
          );
        })}
        <div ref={bottomRef} />
      </Box>

      {/* Input bar */}
      <Box
        sx={{
          bgcolor: '#f0f0f0',
          px: 1.5,
          py: 1,
          display: 'flex',
          alignItems: 'flex-end',
          gap: 1,
          borderTop: '1px solid #ddd',
        }}
      >
        <TextField
          multiline
          maxRows={4}
          fullWidth
          placeholder="Type a message"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKey}
          size="small"
          InputProps={{
            sx: {
              bgcolor: '#fff',
              borderRadius: 3,
              fontSize: 14.5,
              px: 1,
            },
          }}
        />
        <IconButton
          onClick={handleSend}
          disabled={!input.trim() || !connected}
          sx={{
            bgcolor: '#25D366',
            color: '#fff',
            width: 44,
            height: 44,
            flexShrink: 0,
            '&:hover': { bgcolor: '#1ebe5a' },
            '&.Mui-disabled': { bgcolor: '#ccc', color: '#fff' },
          }}
        >
          <SendIcon fontSize="small" />
        </IconButton>
      </Box>

      <MembersDrawer open={membersOpen} onClose={() => setMembersOpen(false)} room={room} />
    </Box>
  );
}
