import { useEffect, useRef, useState, useCallback } from 'react';
import { createWebSocket } from '../api';

export function useWebSocket(roomId, token, onMessage) {
  const wsRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const pingRef = useRef(null);

  const connect = useCallback(() => {
    if (!roomId || !token) return;

    const ws = createWebSocket(roomId, token);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      pingRef.current = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'ping' }));
        }
      }, 25000);
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'pong') return;
        onMessage(data);
      } catch {
        // ignore
      }
    };

    ws.onclose = () => {
      setConnected(false);
      clearInterval(pingRef.current);
    };

    ws.onerror = () => {
      setConnected(false);
    };
  }, [roomId, token, onMessage]);

  useEffect(() => {
    connect();
    return () => {
      clearInterval(pingRef.current);
      wsRef.current?.close();
    };
  }, [connect]);

  const send = useCallback((text) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(text);
    }
  }, []);

  return { connected, send };
}
