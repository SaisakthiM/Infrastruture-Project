use crate::{database::AppState, routes::dto::{self, ChatRoomRequest}};
use axum::{
    Json, Router, extract::{Multipart, Path, Query, State, ws::{Message, WebSocket, WebSocketUpgrade, close_code::STATUS}}, handler::{HandlerService, HandlerWithoutStateExt}, http::StatusCode, response::{IntoResponse, Response}, routing::{any, get, post}
};

use serde_json;
use futures_util::{SinkExt, StreamExt, TryStreamExt};
use bcrypt::{DEFAULT_COST, hash, verify};
use jsonwebtoken::{EncodingKey, DecodingKey, Header, Validation, encode, decode};
use sqlx::Row;
use tokio::sync::broadcast;
use uuid::Uuid;
use chrono::{Duration, Utc};
use minio::s3::{MinioClient, MinioClientBuilder, builders::{CompleteMultipartUpload, CreateMultipartUpload, UploadPart}, creds::StaticProvider, http::BaseUrl, response::BucketExistsResponse, response_traits::HasEtagFromHeaders, types::S3Api};
use minio::s3::types::BucketName;


pub async fn chat_home() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "name": "Chatting App API",
        "version": "1.0.0",
        "endpoints": {
            "auth": {
                "POST /users": "Register a new user",
                "POST /login": "Login and get JWT token"
            },
            "users": {
                "GET /users/{user_id}": "Get user details",
                "PUT /users/{user_id}": "Update username",
                "DELETE /users/{user_id}": "Delete user"
            },
            "rooms": {
                "POST /room": "Create a room",
                "POST /room/join": "Join a room",
                "GET /rooms?user_id=": "List rooms for a user",
                "GET /room/{room_id}/members": "List members in a room"
            },
            "messages": {
                "POST /message": "Send a message",
                "GET /message?room_id=&user_id=": "Get messages in a room"
            },
            "websocket": {
                "WS /ws/{room_id}?token=": "Real-time chat"
            }
        }
    }))
}


pub async fn create_message(
    State(state): State<AppState>,
    Json(request): Json<dto::CreateMessageRequest>,
) -> Result<Json<dto::MessageResponse>, StatusCode> {
    let id = Uuid::new_v4();
    let timestamp = Utc::now();

    let result = sqlx::query(
        r#"
        INSERT INTO messages (
            id,
            room_id,
            sender_id,
            content,
            created_at
        )
        VALUES ($1, $2, $3, $4, $5)
        "#
    )
    .bind(id)
    .bind(request.room_id)
    .bind(request.sender_id)
    .bind(&request.content)
    .bind(timestamp)
    .execute(&state.db)
    .await;

    println!("{:?}", result);

    result.map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    Ok(Json(dto::MessageResponse { id }))
}

pub async fn create_user(
    State(state): State<AppState>,
    Json(request): Json<dto::CreateUserRequest>,
) -> Result<Json<dto::AuthResponse>, StatusCode> {
    let id = Uuid::new_v4();
    let timestamp = Utc::now();

    let password_hash = hash(&request.password, DEFAULT_COST)
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let result = sqlx::query(
        r#"
        INSERT INTO users (id, username, password_hash, created_at)
        VALUES ($1, $2, $3, $4)
        "#
    )
    .bind(id)
    .bind(&request.username)
    .bind(&password_hash)
    .bind(timestamp)
    .execute(&state.db)
    .await;

    println!("{:?}", result);

    result.map_err(|e| {
        println!("DB Error: {:?}", e);
        StatusCode::INTERNAL_SERVER_ERROR
    })?;

    let token = create_token(id).map_err(|e| {
        println!("JWT Error: {:?}", e);
        StatusCode::INTERNAL_SERVER_ERROR
    })?;

    Ok(Json(dto::AuthResponse { id, token }))
}

pub async fn create_room(
    State(pool): State<AppState>,
    Json(payload): Json<dto::ChatRoomRequest>,
) -> Result<Json<dto::ChatRoomResponse>, (StatusCode, String)> {
    let room_id = Uuid::new_v4();

    let mut tx = match pool.db.begin().await {
        Ok(tx) => tx,
        Err(e) => {
            eprintln!("DB begin error: {:?}", e);
            return Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string()));
        }
    };

    if let Err(e) = sqlx::query("INSERT INTO chat_rooms (id, name, created_at) VALUES ($1, $2, now())")
        .bind(room_id)
        .bind(&payload.name)
        .execute(&mut *tx)
        .await
    {
        eprintln!("Insert chat_rooms error: {:?}", e);
        return Err((StatusCode::BAD_REQUEST, e.to_string()));
    }

    if let Err(e) = sqlx::query(
        "INSERT INTO room_members (room_id, user_id, last_seen_at) VALUES ($1, $2, now())"
    )
    .bind(room_id)
    .bind(payload.creator_id)
    .execute(&mut *tx)
    .await
    {
        eprintln!("Insert room_members error: {:?}", e);
        return Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string()));
    }

    let row = match sqlx::query("SELECT name FROM chat_rooms WHERE id=$1")
        .bind(room_id)
        .fetch_one(&mut *tx)
        .await
    {
        Ok(row) => row,
        Err(e) => {
            eprintln!("Select chat_rooms error: {:?}", e);
            return Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string()));
        }
    };

    if let Err(e) = tx.commit().await {
        eprintln!("Commit error: {:?}", e);
        return Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string()));
    }

    Ok(Json(dto::ChatRoomResponse {
        id: room_id,
        name: row.get("name"),
        creator_id: payload.creator_id,
    }))
}


// Join room endpoint
pub async fn join_room(
    State(pool): State<AppState>,
    Json(payload): Json<dto::JoinRoomRequest>,
) -> Result<StatusCode, (StatusCode, String)> {
    let mut tx = match pool.db.begin().await {
        Ok(tx) => tx,
        Err(e) => return Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string())),
    };
    sqlx::query(
        "INSERT INTO room_members (room_id, user_id, last_seen_at)
         VALUES ($1, $2, now())
         ON CONFLICT (room_id, user_id) DO UPDATE SET last_seen_at = now()"
    )
    .bind(payload.room_id)
    .bind(payload.user_id)
    .execute(&pool.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    Ok(StatusCode::CREATED)
}


pub async fn get_message(
    State(state): State<AppState>,
    Query(request): Query<dto::MessageRequest>,
) -> Result<StatusCode, StatusCode> {
    let result = sqlx::query(
        r#"
        SELECT m.*
        FROM messages m
        JOIN room_members rm
            ON rm.room_id = m.room_id
        WHERE m.room_id = $1
        AND rm.user_id = $2
        ORDER BY m.created_at ASC;
        "#
    )
    .bind(request.room_id)
    .bind(request.user_id)
    .fetch_all(&state.db)
    .await;

    println!("{:?}", result);

    result.map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    Ok(StatusCode::CREATED)
}

pub fn create_token(user_id: Uuid) -> Result<String, jsonwebtoken::errors::Error> {
    let expiration = Utc::now()
        .checked_add_signed(Duration::hours(24))
        .unwrap()
        .timestamp() as usize;

    let claims = dto::Claims {
        sub: user_id.to_string(),
        exp: expiration,
    };

    let secret = std::env::var("JWT_SECRET").unwrap_or_else(|_| "secret".to_string());

    encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(secret.as_bytes()),
    )
}

pub async fn login(
    State(state): State<AppState>,
    Json(request): Json<dto::LoginRequest>,
) -> Result<Json<dto::AuthResponse>, StatusCode> {
    let row: (Uuid, String) = sqlx::query_as(
        r#"
        SELECT id, password_hash
        FROM users
        WHERE username = $1
        "#
    )
    .bind(&request.username)
    .fetch_one(&state.db)
    .await
    .map_err(|e| {
        println!("DB Error: {:?}", e);
        StatusCode::UNAUTHORIZED
    })?;

    let (user_id, password_hash) = row;

    let valid = verify(&request.password, &password_hash)
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    if !valid {
        return Err(StatusCode::UNAUTHORIZED);
    }

    let token = create_token(user_id).map_err(|e| {
        println!("JWT Error: {:?}", e);
        StatusCode::INTERNAL_SERVER_ERROR
    })?;

    Ok(Json(dto::AuthResponse { id: user_id, token }))
}


pub async fn handler(
    ws: WebSocketUpgrade,
    Path(room_id): Path<Uuid>,
    Query(params): Query<dto::WsParams>,
    State(state): State<AppState>,
) -> Response {
    let secret = std::env::var("JWT_SECRET").unwrap_or_else(|_| "secret".to_string());

    let token_data = decode::<dto::Claims>(
        &params.token,
        &DecodingKey::from_secret(secret.as_bytes()),
        &Validation::default(),
    );

    let user_id = match token_data {
        Ok(data) => match Uuid::parse_str(&data.claims.sub) {
            Ok(id) => id,
            Err(_) => return StatusCode::UNAUTHORIZED.into_response(),
        },
        Err(_) => return StatusCode::UNAUTHORIZED.into_response(),
    };

    // Extractors end here. We move raw data types (Uuid, AppState) into the socket closure.
    ws.on_upgrade(move |socket| handle_socket(socket, user_id, room_id, state))
}

// 3. The Connection Coordinator (Converts Socket Worker Result into void)
async fn handle_socket(socket: WebSocket, user_id: Uuid, room_id: Uuid, state: AppState) {
    // Pass the actual upgraded raw socket and variables into our core logic
    match handle_socket_core(socket, user_id, room_id, state).await {
        Ok(_) => println!("User {} cleanly disconnected from room {}", user_id, room_id),
        Err(e) => eprintln!("Socket error occurred for user {} in room {}: {:?}", user_id, room_id, e),
    }
}

// 4. The Fallible Core Worker (NO Extractors, Plain Rust arguments only!)

async fn handle_socket_core(
    socket: WebSocket, 
    user_id: Uuid, 
    room_id: Uuid, 
    state: AppState
) -> Result<(), dto::SocketError> {
    
    // Now socket.split() works perfectly!
    let (mut sender, mut receiver) = socket.split();

    // 1. Get/Create Room Channel
    let tx = {
        let mut rooms = state.rooms.lock().await;
        rooms.entry(room_id)
            .or_insert_with(|| broadcast::channel(32).0)
            .clone()
    };
    let mut rx = tx.subscribe();

    // 2. Fetch history & update last seen
    let last_seen: (chrono::DateTime<Utc>,) = sqlx::query_as(
        "SELECT last_seen_at FROM room_members WHERE room_id = $1 AND user_id = $2"
    )
    .bind(room_id)
    .bind(user_id)
    .fetch_one(&state.db)
    .await
    .unwrap_or((chrono::DateTime::from_timestamp(0, 0).unwrap(),));

    sqlx::query("UPDATE room_members SET last_seen_at = now() WHERE room_id = $1 AND user_id = $2")
        .bind(room_id)
        .bind(user_id)
        .execute(&state.db)
        .await?; // <-- using ? now

    let missed = sqlx::query_as::<_, dto::MessageRow>(
        r#"SELECT id, room_id, sender_id, content, created_at FROM messages 
           WHERE room_id = $1 AND created_at > $2 ORDER BY created_at ASC"#
    )
    .bind(room_id)
    .bind(last_seen.0)
    .fetch_all(&state.db)
    .await?; // <-- using ? now

    for msg in missed {
        let json = serde_json::to_string(&msg)?;
        sender.send(Message::Text(json.into())).await?; // <-- using ? now
    }

    // 3. Spawn Broadcast-to-Client Task
    let mut send_task = tokio::spawn(async move {
        while let Ok(msg) = rx.recv().await {
            if sender.send(Message::Text(msg.into())).await.is_err() {
                break;
            }
        }
    });

    let state2 = state.clone();
    let tx_clone = tx.clone();

    // 4. Spawn Client-to-Room Task
    let mut recv_task = tokio::spawn(async move {
        while let Some(Ok(msg)) = receiver.next().await {
            match msg {
                Message::Text(text) => {
                    if text.trim_start().starts_with('{') {
                        if let Ok(v) = serde_json::from_str::<serde_json::Value>(&text) {
                            if v.get("type").and_then(|t| t.as_str()) == Some("ping") {
                                continue;
                            }
                        }
                    }

                    let msg_id = Uuid::new_v4();
                    let timestamp = Utc::now();
                    
                    let _ = sqlx::query(
                        r#"INSERT INTO messages (id, room_id, sender_id, content, created_at)
                           VALUES ($1, $2, $3, $4, $5)"#
                    )
                    .bind(msg_id)
                    .bind(room_id)
                    .bind(user_id)
                    .bind(text.as_str())
                    .bind(timestamp)
                    .execute(&state2.db)
                    .await;

                    let payload = serde_json::json!({
                        "id": msg_id,
                        "room_id": room_id,
                        "sender_id": user_id,
                        "content": text.as_str(),
                        "created_at": timestamp,
                    }).to_string();

                    let _ = tx_clone.send(payload);
                }
                Message::Close(_) => break,
                _ => {}
            }
        }
    });

    // 5. Race tasks
    tokio::select! {
        _ = &mut send_task => recv_task.abort(),
        _ = &mut recv_task => send_task.abort(),
    }

    // 6. Update last seen upon exit
    sqlx::query("UPDATE room_members SET last_seen_at = now() WHERE room_id = $1 AND user_id = $2")
        .bind(room_id)
        .bind(user_id)
        .execute(&state.db)
        .await?;

    Ok(())
}


pub async fn get_user_rooms(
    State(pool): State<AppState>,
    Query(params): Query<dto::GetRoomsParams>,
) -> Result<Json<Vec<dto::RoomRow>>, (StatusCode, String)> {
    let mut tx = match pool.db.begin().await {
        Ok(tx) => tx,
        Err(e) => return Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string())),
    };
    let rooms = sqlx::query_as::<_, dto::RoomRow>(
        "SELECT DISTINCT cr.id, cr.name, cr.created_at 
         FROM chat_rooms cr
         LEFT JOIN room_members rm ON cr.id = rm.room_id
         WHERE rm.user_id = $1 OR cr.id IN (
             SELECT room_id FROM room_members WHERE user_id = $1
         )
         ORDER BY cr.created_at DESC"
    )
    .bind(params.user_id)
    .fetch_all(&mut *tx)
    .await
    .map_err(|e| {
        eprintln!("Database error: {:?}", e);
        (StatusCode::INTERNAL_SERVER_ERROR, e.to_string())
    })?;

    Ok(Json(rooms))
}



pub async fn get_room_members(
    State(state): State<AppState>,
    Path(room_id): Path<Uuid>,
) -> Result<Json<Vec<dto::MemberRow>>, StatusCode> {
    let members = sqlx::query_as::<_, dto::MemberRow>(
        r#"
        SELECT rm.user_id, u.username, rm.last_seen_at
        FROM room_members rm
        JOIN users u ON u.id = rm.user_id
        WHERE rm.room_id = $1
        ORDER BY u.username ASC
        "#
    )
    .bind(room_id)
    .fetch_all(&state.db)
    .await
    .map_err(|e| {
        println!("DB Error: {:?}", e);
        StatusCode::INTERNAL_SERVER_ERROR
    })?;

    Ok(Json(members))
}

pub async fn delete_user(
    State(state): State<AppState>,
    Path(user_id): Path<Uuid>,
) -> Result<StatusCode, StatusCode> {
    let result = sqlx::query("DELETE FROM users WHERE id = $1")
        .bind(user_id)
        .execute(&state.db)
        .await
        .map_err(|e| {
            println!("DB Error: {:?}", e);
            StatusCode::INTERNAL_SERVER_ERROR
        })?;

    if result.rows_affected() == 0 {
        return Err(StatusCode::NOT_FOUND);
    }

    Ok(StatusCode::NO_CONTENT)
}


pub async fn modify_user(
    State(state): State<AppState>,
    Path(user_id): Path<Uuid>,
    Json(body): Json<dto::ModifyName>,
) -> Result<StatusCode, StatusCode> {
    let result = sqlx::query("UPDATE users SET username=$1 WHERE id=$2")
        .bind(&body.new_name)
        .bind(user_id)
        .execute(&state.db)
        .await
        .map_err(|e| {
            println!("DB Error: {:?}", e);
            StatusCode::INTERNAL_SERVER_ERROR
        })?;

    if result.rows_affected() == 0 {
        return Err(StatusCode::NOT_FOUND);
    }

    Ok(StatusCode::NO_CONTENT)
}

pub async fn get_user(
    State(state): State<AppState>,
    Path(user_id): Path<Uuid>,
) -> Result<Json<dto::UserRow>, StatusCode> {
    let user = sqlx::query_as::<_, dto::UserRow>(
        "SELECT id, username, created_at FROM users WHERE id = $1"
    )
    .bind(user_id)
    .fetch_one(&state.db)
    .await
    .map_err(|e| {
        println!("DB Error: {:?}", e);
        StatusCode::NOT_FOUND
    })?;

    Ok(Json(user))
}


#[allow(dead_code)]
pub fn create_client() -> Result<MinioClient, Box<dyn std::error::Error + Send + Sync>> {
    let base_url = "http://localhost:9000".parse::<BaseUrl>()?;

    let static_provider = StaticProvider::new("minioadmin", "minioadmin", None);

    let client = MinioClientBuilder::new(base_url.clone())
        .provider(Some(static_provider))
        .build()?;
    Ok(client)
}

pub async fn create_bucket_if_not_exists(
    bucket: &str,
    client: &MinioClient,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let bucket = BucketName::try_from(bucket)?;
    let resp: BucketExistsResponse = client.bucket_exists(bucket.clone())?.build().send().await?;

    if !resp.exists() {
        client.create_bucket(bucket)?.build().send().await?;
    };
    Ok(())
}

pub async fn file_upload(
    mut multipart: Multipart,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let client: MinioClient = create_client()?;
    let bucket: &str = "file-upload-rust-bucket";

    // Ensure bucket exists
    create_bucket_if_not_exists(bucket, &client).await?;

    while let Some(field) = multipart.next_field().await? {
        let file_name = field.file_name().unwrap_or("unknown_file").to_string();

        // Start multipart upload
        let create_res = client
            .create_multipart_upload(
                BucketName::try_from(bucket)?,
                file_name.clone(),
            )?
            .build()
            .send()
            .await?;
        let upload_id = create_res.upload_id().await;
        let upload_id_2 = upload_id?.clone();

        let mut completed_parts = Vec::new();
        let mut part_number = 1;

        // Stream file chunks
        let mut stream = field.into_stream();
        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;

            let part_res = client
                .upload_part(
                    BucketName::try_from(bucket)?,
                    file_name.clone(),
                    upload_id_2.as_ref(),
                    part_number,
                    chunk.clone().into(),
                )?
                .build()
                .send()
                .await?;

            let etag = part_res.etag()?;
            let part_size = chunk.len() as u64;
            completed_parts.push(minio::s3::types::PartInfo::new(part_number, etag, part_size, None));
            part_number += 1;
        }

        // Complete upload
        client
            .complete_multipart_upload(
                BucketName::try_from(bucket)?,
                file_name.clone(),
                upload_id_2.as_ref(),
                completed_parts,
            )?
            .build()
            .send()
            .await?;
    }

    Ok(())
}

