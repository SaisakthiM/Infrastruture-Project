/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        whatsapp: {
          green: '#25D366',
          dark: '#111B21',
          darker: '#0A0E11',
          light: '#F0F2F5',
          lighter: '#FFFFFF',
          gray: '#54656F',
          border: '#E5E7EB',
          bg: '#ECE5DD'
        },
        aurora: {
          900: '#05060f',
          800: '#0b0f24',
          700: '#121833',
          600: '#1b2348',
          glass: 'rgba(255,255,255,0.06)',
          border: 'rgba(255,255,255,0.10)',
          mint: '#34e89e',
          teal: '#0bd6c4',
          violet: '#7f5af0',
          pink: '#ff6fb5',
          amber: '#ffd166'
        }
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'Helvetica Neue', 'sans-serif']
      },
      backgroundImage: {
        'aurora-gradient': 'radial-gradient(circle at 20% 20%, rgba(127,90,240,0.35), transparent 40%), radial-gradient(circle at 80% 0%, rgba(11,214,196,0.30), transparent 45%), radial-gradient(circle at 50% 100%, rgba(52,232,158,0.20), transparent 50%), linear-gradient(160deg, #05060f 0%, #0b0f24 50%, #121833 100%)',
        'btn-gradient': 'linear-gradient(135deg, #34e89e 0%, #0bd6c4 100%)',
        'btn-gradient-hover': 'linear-gradient(135deg, #0bd6c4 0%, #34e89e 100%)',
        'sent-gradient': 'linear-gradient(135deg, #34e89e 0%, #0bd6c4 100%)',
        'shimmer': 'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.25) 50%, rgba(255,255,255,0) 100%)'
      },
      keyframes: {
        slideIn: {
          from: { opacity: 0, transform: 'translateY(12px) scale(0.98)' },
          to: { opacity: 1, transform: 'translateY(0) scale(1)' }
        },
        floatSlow: {
          '0%, 100%': { transform: 'translate(0px, 0px)' },
          '50%': { transform: 'translate(20px, -30px)' }
        },
        floatSlower: {
          '0%, 100%': { transform: 'translate(0px, 0px)' },
          '50%': { transform: 'translate(-30px, 25px)' }
        },
        pulseGlow: {
          '0%, 100%': { opacity: 0.6, transform: 'scale(1)' },
          '50%': { opacity: 1, transform: 'scale(1.15)' }
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' }
        },
        gradientShift: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' }
        }
      },
      animation: {
        'slide-in': 'slideIn 0.35s cubic-bezier(0.22, 1, 0.36, 1)',
        'float-slow': 'floatSlow 14s ease-in-out infinite',
        'float-slower': 'floatSlower 18s ease-in-out infinite',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'shimmer': 'shimmer 2.2s linear infinite',
        'gradient-shift': 'gradientShift 8s ease infinite'
      }
    }
  },
  plugins: []
}
