import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuthStore } from '../store/authStore'
import { roomAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'

function avatarGradient(seed) {
  const gradients = [
    'from-aurora-mint to-aurora-teal',
    'from-aurora-violet to-aurora-pink',
    'from-aurora-amber to-aurora-pink',
    'from-aurora-teal to-aurora-violet',
    'from-aurora-mint to-aurora-violet',
  ]
  let hash = 0
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) % gradients.length
  return gradients[Math.abs(hash)]
}

export default function ChatList({ selectedRoomId, onRoomSelect, onLogout }) {
  const { user, logout } = useAuthStore()
  const [rooms, setRooms] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [newRoomName, setNewRoomName] = useState('')

  useEffect(() => {
    const loadRooms = async () => {
      if (user?.id) {
        try {
          const data = await roomAPI.getUserRooms(user.id)
          setRooms(Array.isArray(data) ? data : [])
        } catch (error) {
          console.error('Failed to load rooms:', error)
          setRooms([])
        } finally {
          setIsLoading(false)
        }
      }
    }

    loadRooms()
    const interval = setInterval(loadRooms, 5000)
    return () => clearInterval(interval)
  }, [user?.id])

  const handleCreateRoom = async (e) => {
    e.preventDefault()
    if (!newRoomName.trim()) return

    try {
      const response = await roomAPI.createRoom(newRoomName, user.id)

      if (response && response.id) {
        await roomAPI.joinRoom(response.id, user.id)
      }

      setNewRoomName('')
      setShowCreateDialog(false)

      const data = await roomAPI.getUserRooms(user.id)
      setRooms(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error('Failed to create room:', error)
    }
  }

  const handleLogout = () => {
    logout()
    onLogout()
  }

  const filteredRooms = rooms.filter(room =>
    room.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="h-screen w-full sm:w-80 glass border-r border-aurora-border flex flex-col flex-shrink-0 relative z-10">
      {/* Header */}
      <div className="p-4 border-b border-aurora-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-extrabold text-gradient">Whisper</h1>
            <p className="text-xs text-white/50 mt-0.5">{user?.username}</p>
          </div>
          <motion.button
            onClick={handleLogout}
            whileTap={{ scale: 0.9 }}
            className="icon-btn text-white/70 hover:text-white"
            title="Logout"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
          </motion.button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <svg className="absolute left-3 top-3 w-5 h-5 text-white/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Search chats..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 text-sm"
          />
        </div>
      </div>

      {/* Create Room Button */}
      <div className="p-3 border-b border-aurora-border">
        <AnimatePresence mode="wait" initial={false}>
          {!showCreateDialog ? (
            <motion.button
              key="new-chat"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateDialog(true)}
              whileTap={{ scale: 0.98 }}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              New Chat
            </motion.button>
          ) : (
            <motion.form
              key="create-form"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleCreateRoom}
              className="space-y-2 overflow-hidden"
            >
              <input
                autoFocus
                type="text"
                placeholder="Room name..."
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                className="input-field text-sm"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 text-sm py-2 bg-btn-gradient text-aurora-900 font-semibold rounded-lg hover:opacity-90 transition-opacity"
                >
                  Create
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateDialog(false)}
                  className="flex-1 text-sm py-2 glass text-white rounded-lg hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="p-4 space-y-2">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-16 rounded-xl shimmer-bg glass" />
            ))}
          </div>
        ) : filteredRooms.length === 0 ? (
          <div className="p-6 text-center text-white/40 text-sm">
            {searchTerm ? 'No chats found' : 'No chats yet. Create one!'}
          </div>
        ) : (
          <AnimatePresence>
            {filteredRooms.map((room, i) => (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, delay: i * 0.03 }}
                onClick={() => onRoomSelect(room.id)}
                className={`m-2 p-3 cursor-pointer rounded-xl flex items-center gap-3 transition-all duration-200 ${
                  selectedRoomId === room.id
                    ? 'bg-white/10 ring-1 ring-aurora-teal/40'
                    : 'hover:bg-white/5'
                }`}
              >
                <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${avatarGradient(room.name)} flex items-center justify-center text-aurora-900 font-bold text-lg shrink-0`}>
                  {room.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-white truncate">{room.name}</h3>
                  <p className="text-xs text-white/40 mt-0.5">
                    {formatDistanceToNow(new Date(room.created_at), { addSuffix: true })}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  )
}
